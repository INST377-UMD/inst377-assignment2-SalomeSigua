// Load quote for index.html
function loadQuote() {
  fetch('https://zenquotes.io/api/random')
    .then((response) => response.json())
    .then((data) => {
      const quote = data[0].q + ' — ' + data[0].a;
      document.getElementById('quote-box').innerText = quote;
    })
    .catch((err) => {
      console.error('Failed to fetch quote', err);
      document.getElementById('quote-box').innerText = 'Could not load quote.';
    });
}

if (window.location.pathname.includes('index.html')) {
  window.onload = loadQuote;
}

// Dog page logic
function loadRandomDogs() {
  fetch('https://dog.ceo/api/breeds/image/random/10')
    .then((res) => res.json())
    .then((data) => {
      const container = document.getElementById('carousel-container');
      container.innerHTML = '';
      data.message.forEach((url) => {
        const img = document.createElement('img');
        img.src = url;
        img.alt = 'Dog';
        img.classList.add('dog-img');
        container.appendChild(img);
      });
    });
}

function loadDogBreeds() {
  fetch('https://dog.ceo/api/breeds/list/all')
    .then((res) => res.json())
    .then((data) => {
      const breeds = Object.keys(data.message);
      const breedContainer = document.getElementById('breed-buttons');
      breedContainer.innerHTML = '';

      breeds.forEach((breed) => {
        const btn = document.createElement('button');
        btn.innerText = breed;
        btn.onclick = () => loadDogBreedImages(breed);
        breedContainer.appendChild(btn);
      });
    });
}

function loadDogBreedImages(breed) {
  fetch(`https://dog.ceo/api/breed/${breed}/images/random/10`)
    .then((res) => res.json())
    .then((data) => {
      const container = document.getElementById('carousel-container');
      container.innerHTML = '';
      data.message.forEach((url) => {
        const img = document.createElement('img');
        img.src = url;
        img.alt = `${breed}`;
        img.classList.add('dog-img');
        container.appendChild(img);
      });
    });
}

if (window.location.pathname.includes('dogs.html')) {
  window.onload = () => {
    loadRandomDogs();
    loadDogBreeds();
  };
}

// Stock chart logic
const POLYGON_API_KEY = '3Pbpkz2ngOO0jXCz4ovEUtEomYRlQFLm';

function fetchStockData(ticker, days) {
  const end = new Date().toISOString().split('T')[0];
  const start = new Date(Date.now() - days * 24 * 60 * 60 * 1000)
    .toISOString()
    .split('T')[0];

  const url = `https://api.polygon.io/v2/aggs/ticker/${ticker.toUpperCase()}/range/1/day/${start}/${end}?adjusted=true&sort=asc&limit=${days}&apiKey=${POLYGON_API_KEY}`;

  fetch(url)
    .then((res) => res.json())
    .then((data) => {
      if (!data.results) {
        alert('Invalid ticker or no data available.');
        return;
      }

      const labels = data.results.map((d) =>
        new Date(d.t).toLocaleDateString()
      );
      const prices = data.results.map((d) => d.c);

      renderStockChart(labels, prices, ticker);
    })
    .catch((err) => {
      console.error('Stock fetch error:', err);
    });
}

function renderStockChart(labels, prices, ticker) {
  const ctx = document.getElementById('stock-chart').getContext('2d');
  if (window.stockChart) window.stockChart.destroy();

  window.stockChart = new Chart(ctx, {
    type: 'line',
    data: {
      labels,
      datasets: [{
        label: `${ticker.toUpperCase()} Price`,
        data: prices,
        borderColor: 'blue',
        fill: false
      }]
    },
    options: {
      responsive: true,
      scales: {
        x: { title: { display: true, text: 'Date' } },
        y: { title: { display: true, text: 'Price (USD)' } }
      }
    }
  });
}

if (window.location.pathname.includes('stocks.html')) {
  document.getElementById('stock-form').addEventListener('submit', (e) => {
    e.preventDefault();
    const ticker = document.getElementById('ticker').value;
    const days = parseInt(document.getElementById('days').value);
    fetchStockData(ticker, days);
  });
}
