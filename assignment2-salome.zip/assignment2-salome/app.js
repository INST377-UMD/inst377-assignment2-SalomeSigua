const express = require('express');
const app = express();
const port = 3000;

app.use(express.static(__dirname + '/public'));

app.get('/', (req, res) => {
  res.sendFile('public/index.html', { root: __dirname });
});

app.post('/', (req, res) => {
  res.header('Content-Type', 'application/json');
  console.log('Hitting API!');
  const output = { response: 'Hello!' };
  res.send(JSON.stringify(output));
});

app.listen(port, () => {
  console.log(`Express app listening on port: ${port}`);
});
